#!/bin/sh
act=$1
tid=$2
cd "$(dirname "$0")/.."
case "$(uname -s)" in
    Linux*)
        list_fat="mount -t vfat | sed -E 's/(.+)on (.+) type(.+)/\2/' | sed 's/ /\\\\040/'"
        save3ds="resources/save3ds_fuse_linux"
        chmod +x $save3ds
        ;;
    Darwin*)
        list_fat="mount -t msdos | sed -E 's/(.+)on (.+) \((.+)/\2/' | sed 's/ /\\\\040/'"
        save3ds="resources/save3ds_fuse_mac"
        chmod +x $save3ds
        ;;
    MINGW*|MSYS_NT*|CYGWIN*)
        list_fat="mount | grep vfat | sed -E 's/(.+)on (.+) type(.+)/\2/' | sed 's/ /\\\\040/'"
        save3ds="resources/save3ds_fuse.exe"
        ;;
esac
if [ "$act" = "fixperm" ]; then
    for i in JPN EUR USA; do
        chmod +x $i
        chmod +x backup/backup_$i
        chmod +x backup/restore_$i
    done
    exit
fi
for i in $(sh -c "$list_fat"); do
    if [ -d "$(printf $i)/Nintendo 3DS" ]; then
        case "$act" in
            inject)
                $save3ds --sd "$(printf $i)" extdata/$tid --import --sdext $tid --boot9 resources/boot9.bin --movable resources/movable.sed
                ;;
            backup)
                $save3ds --sd "$(printf $i)" backup/$tid --extract --sdext $tid --boot9 resources/boot9.bin --movable resources/movable.sed
                ;;
            restore)
                $save3ds --sd "$(printf $i)" backup/$tid --import --sdext $tid --boot9 resources/boot9.bin --movable resources/movable.sed
                ;;
        esac
    fi
done
echo "Press ENTER to exit ..."
read DUMMY

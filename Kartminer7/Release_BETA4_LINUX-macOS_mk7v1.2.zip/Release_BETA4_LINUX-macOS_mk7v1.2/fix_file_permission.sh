#!/bin/sh
sh "$(dirname "$0")/resources/find_and_run.sh" fixperm

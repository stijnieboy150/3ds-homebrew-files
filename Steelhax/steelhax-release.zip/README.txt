I completely rewrote steelhax and it should work more reliable now. I am sorry for every user's time I may have wasted with the old versions.  

The game has to be on version 1.0. Just delete any existing update data. Make sure that you started the game once and created a save. You can be sure that there is a save after you get into the main menu of the game. (after choosing a mii)
The bootrate should be much better now (I haven't had any issues as of now).

Greets to MrNbaYoh :)